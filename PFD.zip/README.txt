Course Name: CS373
Unique: 91055

First Name: Andy
Last Name: Hsu
EID: ah28348
E-mail: andyhsu@utexas.edu
Estimated number of hours: 20
Actual    number of hours: 15

Partner First Name: Shreedam
Partner Last Name: Parikh
Partner EID: sp24946
Partner E-mail: shreedam@gmail.com
Partner Estimated number of hours: 20
Partner Actual    number of hours: 15

Turnin CS Username: andyhsu
GitHub ID: andyhsu91
GitHub Repository Name: cs373-pfd

Comments: Heap seems rather pointless if you ordered the vertices to begin with.

----------------
Pair Programming
----------------

I attest to that fact that, of the time spent working on this project,
at least seventy-five (75) percent was spent working with the person
listed above in pair programming.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
